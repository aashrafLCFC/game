================================
**PERSONA**
================================


.. image:: Emily.jpg
   :height: 250px
   :width: 250 px
   :scale: 50 %
   :alt: Emily
   :align: left

**Name**: Emily

**Age**: 9 year

**Occupation**: Student 

**Location**: Manhattan, New York


Emily is in 5th grade and she is the only child of the family. She love to play puzzle games. She wants to become a teacher when grows up.She lives with her parent in a townhouse. The area is really quiet and it's next to Central Park.

She goes to at an elementary school near Central Park. Most of the time her mother picks up after school. During the weekend she love to play with her friends in the park.

She have a lot puzzle games at home. Since her parents don't have time to play with during the week days, she sometime wish to play those games with them and tell them about her day in school. During the weekend she sometime goes to the park with her parents. However every time she goes to park she wants to play with her parents but they are alway talking to their friends. On other days when they have something else to do, they just drop her off at the park. She love playing with her friends but she sometime get board because they alway play the same games. If only she can play with her parents and also have fun with her friends she would be very happy. 

Author: Dekuwin Emmanuella I. Kogda
