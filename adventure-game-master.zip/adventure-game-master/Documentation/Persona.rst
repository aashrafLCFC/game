
Jennifer Meyer
==============


.. image:: http://i.imgur.com/hYIdLaw.jpg?1
   :height: 356
   :width: 427
   :scale: 80
   :alt: alternate text
   :align: center



- **Age:** 37
- **Hobbies:** Hiking, Reading
- **Occupation:** Attorney
- **Location:** Manhattan, New York


Jennifer is an attorney and she works 50 hours a week. Jennifer has been married for about twelve years and she has a ten years old son and a seven years old daughter. Jennifer always wants to spend her free time with her two kids as much as possible. She would like to take them outdoor and play games with them. Jennifer wishes to be a loving parent who can interact with her children and understand them.

.. image:: http://easytourforeveryone.com/images/bing.JPG
   :height: 300px
   :width: 250px
   :scale: 100 %
   :alt: alternate text
   :align: left

- **Name:** Justin Chen
- **Age:** 32
- **Occupation:** Employee of McDonald's
- **Income:** $25,000
- **Location:** Brooklyn, NY


  Justin has been worked at McDonald's for one and half years. He had

  a 7-year-old boy named Bing. Because he works 60 hours per week he

  can't spend much time with his child. Now his kid doesn't talk to him

  much, he really wants to have more time with him.

.. image:: http://i.imgur.com/7YrYkc4.jpg?1
   :height: 356
   :width: 575
   :scale: 80
   :alt: alternate text
   :align: center


- **Name:** Jason Smith
- **Age:** 33
- **Hobbies and Interests:** Traveling, Jogging
- **Occupation:** Accountant
- **Location:** Manhattan, New York

Jason is an accountant who works 50 hours a week at Goldman Sachs. He has an 8 year old son named Bob. Jason has trouble communicating with his son because Bob loves playing games on his iPad. He really wants to spend some time with his son and talk with him more.

================================
**PERSONA**
================================


.. image:: http://i.imgur.com/gKWTwit.jpg
   :height: 250px
   :width: 250 px
   :scale: 50 %
   :alt: Emily
   :align: left

**Name**: Emily

**Age**: 9 year

**Occupation**: Student

**Location**: Manhattan, New York


Emily is in 5th grade and she is the only child of the family. She love to play puzzle games. She wants to become a teacher when grows up.She lives with her parent in a townhouse. The area is really quiet and it's next to Central Park.

She goes to at an elementary school near Central Park. Most of the time her mother picks up after school. During the weekend she love to play with her friends in the park.

She have a lot puzzle games at home. Since her parents don't have time to play with during the week days, she sometime wish to play those games with them and tell them about her day in school. During the weekend she sometime goes to the park with her parents. However every time she goes to park she wants to play with her parents but they are alway talking to their friends. On other days when they have something else to do, they just drop her off at the park. She love playing with her friends but she sometime get board because they alway play the same games. If only she can play with her parents and also have fun with her friends she would be very happy.

Author: Dekuwin Emmanuella I. Kogda


.. image:: http://thumbs.dreamstime.com/z/handsome-35-years-old-man-23960301.jpg
  :height: 300px
  :width:  200px
  :scale:  70
  :alt:  alternate text
  :align: center


- **Name:**: Daniel Reed
- **Age:**: 36
- **Hobbies and Interests:**: Crafts, Repairs, Facebook
- **Occupation:**: Line Manager
- **Location:**: Collegedale, Tennessee

  Daniel is a 36 year old parent who has recently gotten a divorce. He has a daughter who has just turned 10. He works a job as a manager at a factory. He has really good people skills so the day to day handling of the workers really suits him. All of them respect him because of the understanding way he treats them. Daniel has been in the job for a long time and has always worked the late shift. The workers on that shift are like a second family to him. When he comes home he has to sleep until late in the afternoon, so he hasn’t always had a lot of time with his daughter.
Daniel has been living in small towns all his life. He spent most of his time growing up with his brothers and sisters playing outside. As an adult he’s growing to know more about technology, but some of it still really baffles him. He understands and loves Facebook. He plays a lot of games on it to keep him occupied. As much as he understands Facebook, he doesn’t really understand apps. His phone is barely a smartphone.
Now that he only has his daughter once or twice every couple of weeks he wants to find a way to spend more time with her. While he’s been busy with work though she has grown up and no longer wants to play the same games with him or talk about the same things. He has a hard time understanding her new interests because they can’t communicate. He’s read a lot of parenting books and read about parent child relationships on the internet. Everything he’s read has said that he needs to get them both away from technology and go some place for the day.
He has realized though that getting rid of technology is a tall order in this day and age, and because he doesn’t know what his daughter likes, he doesn’t know where to take her. He has tried to take her on hikes but she doesn’t seem to like the outdoors much. He has tried taking her to the movies, but he can’t just keep doing that every single week. He needs to find a way to open a line of communication. He needs to find something they can do together that they both enjoy.
