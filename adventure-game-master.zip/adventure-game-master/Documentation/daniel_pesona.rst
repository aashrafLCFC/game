.. image:: http://thumbs.dreamstime.com/z/handsome-35-years-old-man-23960301.jpg
  :height 300px
  :width  200px
  :scale  70
  :alt:  alternate text
  :align: center


  - **Name:** Daniel Reed
  - **Age:** 36
  - **Hobbies and Interests:** Crafts, Repairs, Facebook
  - **Occupation:** Line Manager
  - **Location:** Collegedale, Tennessee

  Daniel is a 36 year old parent who has recently gotten a divorce. He has a daughter who has just turned 10. He works a job as a manager at a factory. He has really good people skills so the day to day handling of the workers really suits him. All of them respect him because of the understanding way he treats them. Daniel has been in the job for a long time and has always worked the late shift. The workers on that shift are like a second family to him. When he comes home he has to sleep until late in the afternoon, so he hasn’t always had a lot of time with his daughter.
Daniel has been living in small towns all his life. He spent most of his time growing up with his brothers and sisters playing outside. As an adult he’s growing to know more about technology, but some of it still really baffles him. He understands and loves Facebook. He plays a lot of games on it to keep him occupied. As much as he understands Facebook, he doesn’t really understand apps. His phone is barely a smartphone.
Now that he only has his daughter once or twice every couple of weeks he wants to find a way to spend more time with her. While he’s been busy with work though she has grown up and no longer wants to play the same games with him or talk about the same things. He has a hard time understanding her new interests because they can’t communicate. He’s read a lot of parenting books and read about parent child relationships on the internet. Everything he’s read has said that he needs to get them both away from technology and go some place for the day.
He has realized though that getting rid of technology is a tall order in this day and age, and because he doesn’t know what his daughter likes, he doesn’t know where to take her. He has tried to take her on hikes but she doesn’t seem to like the outdoors much. He has tried taking her to the movies, but he can’t just keep doing that every single week. He needs to find a way to open a line of communication. He needs to find something they can do together that they both enjoy.
