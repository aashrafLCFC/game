tests.unit package
==================

Submodules
----------

tests.unit.test_coreapp_views module
------------------------------------

.. automodule:: tests.unit.test_coreapp_views
    :members:
    :undoc-members:
    :show-inheritance:

tests.unit.test_queries module
------------------------------

.. automodule:: tests.unit.test_queries
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: tests.unit
    :members:
    :undoc-members:
    :show-inheritance:
