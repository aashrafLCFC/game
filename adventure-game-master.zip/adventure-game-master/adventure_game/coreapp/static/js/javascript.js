
$(function(){
  var el = document.getElementById("continue")
  if (el) {
    $("#continue").next().remove();
  }
});
